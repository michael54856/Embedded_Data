#ifndef __HOSTFE__
#define __HOSTFE__


void hostFE(int filterWidth, float *filter, int imageHeight, int imageWidth,
            float *inputImage, float *outputImage);

#endif